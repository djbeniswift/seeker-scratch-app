import { PublicKey } from '@solana/web3.js'

export const PROGRAM_ID = new PublicKey('HbzZxjEHa9RPZooGBCR2CzmdjLE3uSfE5RpYMbXyeDUc')

export const TREASURY_SEED = Buffer.from('scratch_treasury')
export const PROFILE_SEED = Buffer.from('scratch_profile')
export const NFT_SEED = Buffer.from('scratch_nft')

export const CARD_COSTS: Record<string, number> = {
  QuickPick: 0.01,
  Lucky7s: 0.05,
  HotShot: 0.05,
  MegaGold: 0.10,
}

export const CARD_CONFIG = {
  QuickPick: {
    name: 'QUICK PICK',
    subtitle: 'Fast & fun',
    cost: 0.01,
    costLabel: '0.01 SOL',
    topPrize: '0.5 SOL',
    color: 'cyan',
    accentColor: '#00e5ff',
    bgGradient: 'linear-gradient(135deg, #001420 0%, #00202e 50%, #001420 100%)',
    border: 'rgba(0,229,255,0.2)',
    btnClass: 'btn-cyan',
    odds: '1 in 4',
    tag: 'INSTANT',
    tagClass: 'tag-cyan',
    emoji: '⚡',
  },
  Lucky7s: {
    name: 'LUCKY 7s',
    subtitle: 'Triple 7 = jackpot',
    cost: 0.05,
    costLabel: '0.05 SOL',
    topPrize: '2 SOL',
    color: 'purple',
    accentColor: '#a855f7',
    bgGradient: 'linear-gradient(135deg, #0d0014 0%, #160020 50%, #0d0014 100%)',
    border: 'rgba(168,85,247,0.2)',
    btnClass: 'btn-purple',
    odds: '1 in 5',
    tag: 'CLASSIC',
    tagClass: 'tag-purple',
    emoji: '7️⃣',
  },
  HotShot: {
    name: 'HOT SHOT',
    subtitle: 'High risk, high reward',
    cost: 0.05,
    costLabel: '0.05 SOL',
    topPrize: '5 SOL',
    color: 'red',
    accentColor: '#ff3d6b',
    bgGradient: 'linear-gradient(135deg, #1a0008 0%, #240010 50%, #1a0008 100%)',
    border: 'rgba(255,61,107,0.2)',
    btnClass: 'btn-red',
    odds: '1 in 8',
    tag: '🔥 HOT',
    tagClass: 'tag-red',
    emoji: '🔥',
  },
  MegaGold: {
    name: 'MEGA GOLD',
    subtitle: 'Highest jackpot on Seeker',
    cost: 0.10,
    costLabel: '0.1 SOL',
    topPrize: '10 SOL',
    color: 'gold',
    accentColor: '#f5c842',
    bgGradient: 'linear-gradient(135deg, #1a1400 0%, #2d2200 50%, #1a1400 100%)',
    border: 'rgba(245,200,66,0.3)',
    btnClass: 'btn-gold',
    odds: '1 in 3',
    tag: '✦ FEATURED',
    tagClass: 'tag-gold',
    emoji: '🏆',
  },
}

export const NFT_TIERS = {
  Silver:   { cost: 0.1,  multiplier: 2,  color: '#c0c0c0', emoji: '⚪' },
  Gold:     { cost: 0.5,  multiplier: 5,  color: '#f5c842', emoji: '🟡' },
  Platinum: { cost: 2.0,  multiplier: 10, color: '#e5e4e2', emoji: '💿' },
  Diamond:  { cost: 5.0,  multiplier: 20, color: '#b9f2ff', emoji: '💎' },
}

export const IDL = {
  version: '0.1.0',
  name: 'seeker_scratch',
  instructions: [
    {
      name: 'initialize',
      accounts: [
        { name: 'treasury', isMut: true, isSigner: false },
        { name: 'admin', isMut: true, isSigner: true },
        { name: 'systemProgram', isMut: false, isSigner: false },
      ],
      args: [],
    },
    {
      name: 'fundTreasury',
      accounts: [
        { name: 'treasury', isMut: true, isSigner: false },
        { name: 'admin', isMut: true, isSigner: true },
        { name: 'systemProgram', isMut: false, isSigner: false },
      ],
      args: [{ name: 'amount', type: 'u64' }],
    },
    {
      name: 'buyAndScratch',
      accounts: [
        { name: 'treasury', isMut: true, isSigner: false },
        { name: 'profile', isMut: true, isSigner: false },
        { name: 'player', isMut: true, isSigner: true },
        { name: 'systemProgram', isMut: false, isSigner: false },
      ],
      args: [{ name: 'cardType', type: { defined: 'CardType' } }],
    },
    {
      name: 'registerReferral',
      accounts: [
        { name: 'refereeProfile', isMut: true, isSigner: false },
        { name: 'referrerProfile', isMut: true, isSigner: false },
        { name: 'referrer', isMut: false, isSigner: false },
        { name: 'referee', isMut: true, isSigner: true },
        { name: 'systemProgram', isMut: false, isSigner: false },
      ],
      args: [],
    },
    {
      name: 'mintBonusNft',
      accounts: [
        { name: 'treasury', isMut: true, isSigner: false },
        { name: 'bonusNft', isMut: true, isSigner: false },
        { name: 'profile', isMut: true, isSigner: false },
        { name: 'player', isMut: true, isSigner: true },
        { name: 'systemProgram', isMut: false, isSigner: false },
      ],
      args: [{ name: 'tier', type: { defined: 'NFTTier' } }],
    },
  ],
  accounts: [
    {
      name: 'Treasury',
      type: {
        kind: 'struct',
        fields: [
          { name: 'admin', type: 'publicKey' },
          { name: 'balance', type: 'u64' },
          { name: 'totalCardsSold', type: 'u64' },
          { name: 'totalPaidOut', type: 'u64' },
          { name: 'totalProfit', type: 'u64' },
          { name: 'dailyPaidOut', type: 'u64' },
          { name: 'dayStartTime', type: 'i64' },
          { name: 'paused', type: 'bool' },
          { name: 'bump', type: 'u8' },
        ],
      },
    },
    {
      name: 'PlayerProfile',
      type: {
        kind: 'struct',
        fields: [
          { name: 'owner', type: 'publicKey' },
          { name: 'pointsThisMonth', type: 'u64' },
          { name: 'pointsAllTime', type: 'u64' },
          { name: 'referralsCount', type: 'u32' },
          { name: 'cardsScratched', type: 'u32' },
          { name: 'totalSpent', type: 'u64' },
          { name: 'totalWon', type: 'u64' },
          { name: 'wins', type: 'u32' },
          { name: 'bonusNft', type: { option: 'publicKey' } },
          { name: 'nftMultiplierCache', type: 'u8' },
          { name: 'referredBy', type: { option: 'publicKey' } },
          { name: 'firstPurchaseTime', type: 'i64' },
        ],
      },
    },
  ],
  types: [
    {
      name: 'CardType',
      type: {
        kind: 'enum',
        variants: [
          { name: 'QuickPick' },
          { name: 'Lucky7s' },
          { name: 'HotShot' },
          { name: 'MegaGold' },
        ],
      },
    },
    {
      name: 'NFTTier',
      type: {
        kind: 'enum',
        variants: [
          { name: 'Silver' },
          { name: 'Gold' },
          { name: 'Platinum' },
          { name: 'Diamond' },
        ],
      },
    },
  ],
  errors: [
    { code: 6000, name: 'GamePaused', msg: 'Game is currently paused' },
    { code: 6001, name: 'InvalidAmount', msg: 'Invalid amount' },
    { code: 6002, name: 'Overflow', msg: 'Arithmetic overflow' },
    { code: 6003, name: 'Unauthorized', msg: 'Unauthorized - admin only' },
    { code: 6004, name: 'TreasuryTooLow', msg: 'Treasury balance too low for this card type' },
    { code: 6005, name: 'InsufficientTreasury', msg: 'Treasury has insufficient funds for payout' },
    { code: 6006, name: 'WithdrawWouldBreakMinimum', msg: 'Withdraw would break minimum treasury requirement' },
    { code: 6007, name: 'AlreadyReferred', msg: 'This wallet has already been referred' },
    { code: 6008, name: 'CannotSelfRefer', msg: 'Cannot refer yourself' },
    { code: 6009, name: 'ReferralNotQualified', msg: "Referee hasn't met 0.1 SOL minimum spend" },
    { code: 6010, name: 'AlreadyHasNFT', msg: 'Player already owns a Bonus NFT' },
  ],
}
