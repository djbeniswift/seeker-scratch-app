'use client'

import { useState, useEffect, useRef } from 'react'
import { useWallet } from '@solana/wallet-adapter-react'
import WalletButton from './components/WalletButton'
import { useScratchProgram } from './hooks/useScratchProgram'
import ScratchModal from './components/ScratchModal'
import { CARD_CONFIG, NFT_TIERS } from './lib/constants'

const RECENT_WINS = [
  { wallet: '7xR4...k2mP', prize: '0.5 SOL', card: 'Mega Gold' },
  { wallet: 'Bx9K...3nQz', prize: '2.0 SOL', card: 'Lucky 7s' },
  { wallet: 'mW2j...p7Lx', prize: '0.05 SOL', card: 'Quick Pick' },
  { wallet: '9kPz...mR4v', prize: '5.0 SOL', card: '🔥 Hot Shot' },
  { wallet: 'qT3n...8sKm', prize: '0.1 SOL', card: 'Lucky 7s' },
  { wallet: 'rK8m...2xPq', prize: '10 SOL', card: '🏆 JACKPOT' },
]

export default function Home() {
  const wallet = useWallet()
  const {
    treasury,
    profile,
    solBalance,
    loading,
    txStatus,
    lastPrize,
    lastError,
    buyAndScratch,
    registerReferral,
    mintBonusNft,
    setTxStatus,
    setLastPrize,
  } = useScratchProgram()

  const [activeCard, setActiveCard] = useState<string | null>(null)
  const [activeNav, setActiveNav] = useState('scratch')
  const [showNFTModal, setShowNFTModal] = useState(false)
  const [referralInput, setReferralInput] = useState('')
  const [referralStatus, setReferralStatus] = useState('')
  const [wonToday, setWonToday] = useState(0)

  // Check for ?ref= in URL on load
  useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    const ref = params.get('ref')
    if (ref && wallet.publicKey && !profile?.referredBy) {
      registerReferral(ref).catch(() => {})
    }
  }, [wallet.publicKey, profile?.referredBy])

  const handleBuy = async (cardType: string): Promise<number> => {
    const prize = await buyAndScratch(cardType)
    if (prize > 0) {
      setWonToday(prev => prev + prize)
    }
    return prize
  }

  const handleReferralSubmit = async () => {
    if (!referralInput) return
    try {
      setReferralStatus('Registering...')
      await registerReferral(referralInput)
      setReferralStatus('✅ Referral registered!')
    } catch {
      setReferralStatus('❌ Invalid address or already referred')
    }
  }

  const copyReferralLink = () => {
    if (!wallet.publicKey) return
    const link = `${window.location.origin}?ref=${wallet.publicKey.toString()}`
    navigator.clipboard.writeText(link)
  }

  const nftMultiplier = profile?.nftMultiplierCache || 1
  const nftTierName = nftMultiplier === 2 ? 'Silver'
    : nftMultiplier === 5 ? 'Gold'
    : nftMultiplier === 10 ? 'Platinum'
    : nftMultiplier === 20 ? 'Diamond'
    : null

  return (
    <>
      <div className="app">

        {/* ── HEADER ── */}
        <header>
          <div className="logo">
            <div className="logo-icon">🎰</div>
            <div>
              <div className="logo-text">SEEKER SCRATCH</div>
              <div className="logo-sub">INSTANT WIN ON SOLANA</div>
            </div>
          </div>
          <WalletButton />
        </header>

        {/* ── BALANCE BAR ── */}
        <div className="balance-bar">
          <div className="balance-item">
            <div className="balance-label">Balance</div>
            <div className="balance-value gold">{solBalance.toFixed(3)} SOL</div>
          </div>
          <div className="balance-divider" />
          <div className="balance-item">
            <div className="balance-label">Won Today</div>
            <div className="balance-value green">{wonToday.toFixed(3)} SOL</div>
          </div>
          <div className="balance-divider" />
          <div className="balance-item">
            <div className="balance-label">Points</div>
            <div className="balance-value">{profile?.pointsThisMonth || 0}</div>
          </div>
        </div>

        {/* ── TICKER ── */}
        <div className="ticker-wrap">
          <div className="ticker-label">🔥 WINS</div>
          <div className="ticker-track">
            <div className="ticker-items">
              {[...RECENT_WINS, ...RECENT_WINS].map((w, i) => (
                <span key={i} className="ticker-item">
                  <span>{w.wallet}</span>
                  <span className="ticker-win">+{w.prize}</span>
                  <span>{w.card}</span>
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* ── STATS ── */}
        <div className="stats-row">
          <div className="stat-cell">
            <div className="stat-value text-gold">{treasury?.totalCardsSold?.toLocaleString() || '0'}</div>
            <div className="stat-label">Cards Sold</div>
          </div>
          <div className="stat-cell">
            <div className="stat-value text-green">
              {treasury ? Math.round((treasury.totalPaidOut / Math.max(treasury.totalPaidOut + treasury.totalProfit, 1)) * 100) : 0}%
            </div>
            <div className="stat-label">Payout Rate</div>
          </div>
          <div className="stat-cell">
            <div className="stat-value text-cyan">{treasury?.balance?.toFixed(2) || '0'}</div>
            <div className="stat-label">Treasury SOL</div>
          </div>
        </div>

        {/* REST OF THE COMPONENT - keeping it the same */}
        {activeNav === 'scratch' && (
          <>
            <div className="section-header">
              <div className="section-title">CHOOSE YOUR CARD</div>
              <div className="section-badge badge-live">● LIVE</div>
            </div>

            <div className="cards-grid">
              {/* Featured - Mega Gold */}
              <div
                className="scratch-card card-gold featured"
                onClick={() => setActiveCard('MegaGold')}
                style={{ opacity: treasury && treasury.balance < 50 ? 0.5 : 1 }}
              >
                <div className="card-grid-pattern" />
                <div className="card-featured-inner">
                  <div>
                    <div className="card-tag tag-gold">✦ FEATURED</div>
                    <div className="card-name-lg text-gold">MEGA<br />GOLD</div>
                    <div className="card-subtitle">Highest jackpot on Seeker</div>
                    <div className="card-cost">
                      <div className="cost-pill text-gold">0.1 SOL</div>
                      <div className="odds-text">
                        {treasury && treasury.balance < 50 ? '🔒 LOW TREASURY' : '1 in 3 wins'}
                      </div>
                    </div>
                  </div>
                  <div className="featured-right">
                    <div className="featured-jackpot-label">TOP PRIZE</div>
                    <div className="prize-amount-lg text-gold">
                      {treasury ? Math.min(10, treasury.balance / 2).toFixed(0) : '10'}
                      <span className="prize-sol">SOL</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Quick Pick */}
              <div className="scratch-card card-cyan" onClick={() => setActiveCard('QuickPick')}>
                <div className="card-grid-pattern" />
                <div className="card-inner">
                  <div>
                    <div className="card-tag tag-cyan">INSTANT</div>
                    <div className="card-name text-cyan">QUICK<br />PICK</div>
                    <div className="card-subtitle">Fast & fun</div>
                  </div>
                  <div className="card-prize">
                    <div className="prize-label">TOP PRIZE</div>
                    <div className="prize-amount text-cyan">0.5<span className="prize-sol">SOL</span></div>
                    <div className="card-cost">
                      <div className="cost-pill" style={{ color: 'var(--cyan)' }}>0.01 SOL</div>
                      <div className="odds-text">1 in 4</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Lucky 7s */}
              <div
                className="scratch-card card-purple"
                onClick={() => setActiveCard('Lucky7s')}
                style={{ opacity: treasury && treasury.balance < 5 ? 0.5 : 1 }}
              >
                <div className="card-grid-pattern" />
                <div className="card-inner">
                  <div>
                    <div className="card-tag tag-purple">CLASSIC</div>
                    <div className="card-name text-purple">LUCKY<br />7s</div>
                    <div className="card-subtitle">Triple 7 = jackpot</div>
                  </div>
                  <div className="card-prize">
                    <div className="prize-label">TOP PRIZE</div>
                    <div className="prize-amount text-purple">2<span className="prize-sol">SOL</span></div>
                    <div className="card-cost">
                      <div className="cost-pill" style={{ color: 'var(--purple)' }}>0.05 SOL</div>
                      <div className="odds-text">{treasury && treasury.balance < 5 ? '🔒' : '1 in 5'}</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Hot Shot */}
              <div
                className="scratch-card card-red"
                onClick={() => setActiveCard('HotShot')}
                style={{ opacity: treasury && treasury.balance < 20 ? 0.5 : 1 }}
              >
                <div className="card-grid-pattern" />
                <div className="card-inner">
                  <div>
                    <div className="card-tag tag-red">🔥 HOT</div>
                    <div className="card-name text-red">HOT<br />SHOT</div>
                    <div className="card-subtitle">High risk, high reward</div>
                  </div>
                  <div className="card-prize">
                    <div className="prize-label">TOP PRIZE</div>
                    <div className="prize-amount text-red">5<span className="prize-sol">SOL</span></div>
                    <div className="card-cost">
                      <div className="cost-pill" style={{ color: 'var(--red)' }}>0.05 SOL</div>
                      <div className="odds-text">{treasury && treasury.balance < 20 ? '🔒' : '1 in 8'}</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Points Card */}
            <div className="section-header">
              <div className="section-title">YOUR REWARDS</div>
            </div>
            <div className="points-card">
              <div className="points-header">
                <div>
                  <div className="points-title">MONTHLY POINTS</div>
                  <div className="points-amount">{profile?.pointsThisMonth || 0}</div>
                  <div className="points-sub">
                    {profile?.cardsScratched || 0} cards scratched all time
                  </div>
                </div>
                <div className="nft-tier-display">
                  <span>{nftTierName === 'Silver' ? '⚪' : nftTierName === 'Gold' ? '🟡' : nftTierName === 'Platinum' ? '💿' : nftTierName === 'Diamond' ? '💎' : '⬜'}</span>
                  <div>
                    <div style={{ fontSize: 9, opacity: 0.6 }}>{nftTierName || 'NO NFT'}</div>
                    <div className="multiplier-badge">{nftMultiplier}x</div>
                  </div>
                </div>
              </div>
              {!nftTierName && (
                <div style={{ fontSize: 12, color: 'var(--muted)', marginBottom: 12, fontFamily: 'monospace' }}>
                  Upgrade to Silver NFT → earn <span className="text-gold">2x points</span> per scratch
                </div>
              )}
              <button
                className="cta-btn btn-gold"
                style={{ fontSize: 14, padding: 14 }}
                onClick={() => setActiveNav('nfts')}
              >
                {nftTierName ? `${nftTierName.toUpperCase()} NFT ACTIVE — ${nftMultiplier}X POINTS` : 'GET BONUS NFT — MULTIPLY POINTS'}
              </button>
              <div className="points-progress">
                <div
                  className="points-fill"
                  style={{ width: `${Math.min(((profile?.pointsThisMonth || 0) / 1000) * 100, 100)}%` }}
                />
              </div>
              <div className="points-footer">
                <span>{profile?.pointsThisMonth || 0} pts</span>
                <span>Next reward at 1,000 pts</span>
              </div>
            </div>
          </>
        )}

        {/* OTHER TABS - keeping same, just truncating for space */}
        {activeNav === 'ranks' && (
          <div style={{ paddingTop: 8 }}>
            <div className="section-header">
              <div className="section-title">MONTHLY LEADERBOARD</div>
              <div className="section-badge badge-live">● LIVE</div>
            </div>
            <div style={{
              background: 'var(--surface)', border: '1px solid var(--border)',
              borderRadius: 20, padding: 20,
            }}>
              <div style={{ textAlign: 'center', padding: '40px 20px', color: 'var(--muted)', fontFamily: 'monospace', fontSize: 13 }}>
                🏆 Leaderboard loads as players compete<br />
                <span style={{ fontSize: 11, opacity: 0.6, marginTop: 8, display: 'block' }}>
                  Your rank: #{profile ? '?' : 'Connect wallet'}
                </span>
              </div>
            </div>
          </div>
        )}

        {activeNav === 'refer' && (
          <div style={{ paddingTop: 8 }}>
            <div className="section-header">
              <div className="section-title">REFERRALS</div>
            </div>
            <div className="points-card" style={{ marginBottom: 12 }}>
              <div className="points-title" style={{ marginBottom: 8 }}>YOUR REFERRAL LINK</div>
              <div style={{
                background: 'var(--surface2)', borderRadius: 10, padding: '12px 14px',
                fontFamily: 'monospace', fontSize: 11, color: 'var(--muted)',
                border: '1px solid var(--border)', marginBottom: 12,
                wordBreak: 'break-all',
              }}>
                {wallet.publicKey
                  ? `seekerscratch.app?ref=${wallet.publicKey.toString().slice(0, 20)}...`
                  : 'Connect wallet to get your link'}
              </div>
              <button
                className="cta-btn btn-gold"
                style={{ fontSize: 14, padding: 14 }}
                onClick={copyReferralLink}
                disabled={!wallet.publicKey}
              >
                📋 COPY REFERRAL LINK
              </button>
            </div>
          </div>
        )}

        {activeNav === 'nfts' && (
          <div style={{ paddingTop: 8 }}>
            <div className="section-header">
              <div className="section-title">BONUS NFTS</div>
            </div>
            <div style={{ fontSize: 12, color: 'var(--muted)', fontFamily: 'monospace', marginBottom: 20, lineHeight: 1.6 }}>
              NFTs multiply your points on every scratch AND every referral. One purchase, permanent boost.
            </div>
            {Object.entries(NFT_TIERS).map(([tier, info]) => {
              const isOwned = nftTierName === tier
              return (
                <div key={tier} style={{
                  background: 'var(--surface)', border: `1px solid ${isOwned ? 'rgba(245,200,66,0.4)' : 'var(--border)'}`,
                  borderRadius: 16, padding: '16px 20px', marginBottom: 12,
                  display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                  boxShadow: isOwned ? '0 0 20px rgba(245,200,66,0.1)' : 'none',
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                    <div style={{ fontSize: 32 }}>{info.emoji}</div>
                    <div>
                      <div style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: 20, letterSpacing: 2, color: info.color }}>
                        {tier}
                        {isOwned && <span style={{ fontSize: 11, color: 'var(--green)', marginLeft: 8, fontFamily: 'monospace' }}>✓ OWNED</span>}
                      </div>
                      <div style={{ fontSize: 11, color: 'var(--muted)', fontFamily: 'monospace' }}>
                        {info.multiplier}x points multiplier
                      </div>
                      <div style={{ fontSize: 11, color: 'var(--gold)', fontFamily: 'monospace' }}>
                        {info.cost} SOL
                      </div>
                    </div>
                  </div>
                  <button
                    className={`cta-btn ${isOwned ? 'btn-disabled' : 'btn-gold'}`}
                    style={{ width: 'auto', padding: '10px 20px', fontSize: 13 }}
                    disabled={isOwned || loading || !wallet.publicKey || !!nftTierName}
                    onClick={() => mintBonusNft(tier)}
                  >
                    {isOwned ? 'OWNED' : nftTierName ? 'HAVE NFT' : 'BUY'}
                  </button>
                </div>
              )
            })}
          </div>
        )}

        {activeNav === 'profile' && (
          <div style={{ paddingTop: 8 }}>
            <div className="section-header">
              <div className="section-title">YOUR STATS</div>
            </div>
            <div className="points-card">
              {wallet.publicKey ? (
                <>
                  <div style={{ fontFamily: 'monospace', fontSize: 11, color: 'var(--muted)', marginBottom: 20, wordBreak: 'break-all' }}>
                    {wallet.publicKey.toString()}
                  </div>
                  {[
                    { label: 'Cards Scratched', value: profile?.cardsScratched || 0 },
                    { label: 'Total Wins', value: profile?.wins || 0 },
                    { label: 'Total Spent', value: `${(profile?.totalSpent || 0).toFixed(3)} SOL` },
                    { label: 'Total Won', value: `${(profile?.totalWon || 0).toFixed(3)} SOL` },
                    { label: 'Referrals', value: profile?.referralsCount || 0 },
                    { label: 'Points (Month)', value: profile?.pointsThisMonth || 0 },
                    { label: 'Points (All Time)', value: profile?.pointsAllTime || 0 },
                    { label: 'NFT Tier', value: nftTierName || 'None' },
                    { label: 'Multiplier', value: `${nftMultiplier}x` },
                  ].map((row, i) => (
                    <div key={i} style={{
                      display: 'flex', justifyContent: 'space-between',
                      padding: '10px 0', borderBottom: '1px solid var(--border)',
                      fontSize: 13,
                    }}>
                      <span style={{ color: 'var(--muted)', fontFamily: 'monospace', fontSize: 11 }}>{row.label}</span>
                      <span style={{ color: 'var(--text)', fontFamily: 'monospace', fontSize: 12 }}>{row.value}</span>
                    </div>
                  ))}
                </>
              ) : (
                <div style={{ textAlign: 'center', padding: '30px 0', color: 'var(--muted)', fontFamily: 'monospace' }}>
                  Connect wallet to see your stats
                </div>
              )}
            </div>
          </div>
        )}

      </div>

      {/* ── NAV BAR ── */}
      <div className="nav-bar">
        {[
          { id: 'scratch', icon: '🎰', label: 'Scratch' },
          { id: 'ranks', icon: '🏆', label: 'Ranks' },
          { id: 'refer', icon: '🤝', label: 'Refer' },
          { id: 'nfts', icon: '💎', label: 'NFTs' },
          { id: 'profile', icon: '👤', label: 'Profile' },
        ].map(nav => (
          <div
            key={nav.id}
            className={`nav-item ${activeNav === nav.id ? 'active' : ''}`}
            onClick={() => setActiveNav(nav.id)}
          >
            <span className="nav-icon">{nav.icon}</span>
            <span>{nav.label}</span>
          </div>
        ))}
      </div>

      {/* ── SCRATCH MODAL ── WITH KEY FIX */}
      {activeCard && (
        <ScratchModal
          key={`${activeCard}-${Date.now()}`}
          cardType={activeCard}
          onClose={() => {
            setActiveCard(null)
            setTxStatus('idle')
            setLastPrize(null)
          }}
          onBuy={handleBuy}
          loading={loading}
          walletConnected={wallet.connected}
          solBalance={solBalance}
        />
      )}
    </>
  )
}